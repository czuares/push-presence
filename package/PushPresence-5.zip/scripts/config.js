"use strict";

 angular.module('config', [])

.constant('ENV', {name:'production',debugEnabled:false})

;